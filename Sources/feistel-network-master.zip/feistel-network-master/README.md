feistel-network
===============
C++ realization of Feistel network
